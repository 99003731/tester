/**
 * @file mathematicalfunction.h
 * @author Shivanshu Shukla (shivanshu.shukla@ltts.com)
 * @brief Few of the mathematical functions such as factorial, prime number etc are constructed here
 * @version 0.1
 * @date 2021-02-23
 * 
 * @copyright Copyright (c) 2021
 * 
 */

# ifndef _MYUTILS_H_
# define _MYUTILS_H_

typedef enum{INCORRECT_NUMBER,CORRECT_NUMBER}result;

double factorial(const unsigned int number);
result isPrime(const unsigned int number);
result isPalindrome(const unsigned int number);
double vsum(int number,...);

# endif
