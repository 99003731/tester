# ifndef _STRINGBR_H_
# define _STRINGBR_H_

# include<stdio.h>
# include<string.h>

char* stringbreak(char*);

# endif
