#include"unity.h"
#include <stdio.h>
#include <string.h>
#include <stringbr.h>

/* Modify these two lines according to the project */
void test_stringbreak_test1(void);
void test_stringbreak_test2(void);

/* Required by the unity test framework */
void setUp(){}

/* Required by the unity test framework */
void tearDown(){}void fileinput(FILE*);
int main()
{
    
    UNITY_BEGIN();

    RUN_TEST(test_stringbreak_test1);
    RUN_TEST(test_stringbreak_test2);

    return UNITY_END();
}

void test_stringbreak_test1(void)
{
    TEST_ASSERT_EQUAL_STRING("$Welcome to LTTS;",stringbreak("Garbage$Welcome to LTTS;ignore"));

    /*Failed case*/
    TEST_ASSERT_EQUAL_STRING("$We LTTS;",stringbreak("Garbage$Welcome to LTTS;ignore"));
}

void test_stringbreak_test2(void)
{
    TEST_ASSERT_EQUAL_STRING("$an example #2 string;",stringbreak("Hello$This is $$an example #2 string;And filled with words"));

    /*Failed case*/
    TEST_ASSERT_EQUAL_STRING("$This is;",stringbreak("Garbage$Welcome to LTTS;ignore"));
}