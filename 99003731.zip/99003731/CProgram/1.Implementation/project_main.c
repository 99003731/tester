#include <filestring.h>
#include <stringbr.h>

int main(int argc, char *argv[])
{
    int choice;
    char str[100];
    char *strbr;
    FILE *fptr;
    do
    {
        printf("\n\n\t\t____STRING BREAK___");
        printf("\n\n1)TO TAKE INPUT FROM USER");
        printf("\n\n2)TO TAKE INPUT FROM FILE");
        printf("\n\n3)TO EXIT");
        printf("\n\nEnter your Choice: ");
        scanf(" %d\n",&choice);
        switch(choice)
        {  
            case 1:
                    printf("\nEnter a string:");
                    fgets(str,100,stdin);
                    strbr=stringbreak(str);
                    printf("%s",strbr);
                    break;
            case 2:
                fptr=fopen("file.txt","rt");
                fileinput(fptr);
                fclose(fptr);
                break;
            case 3:
                return 0;
                break;
            default:
                printf("\nWrong Choice:");
                break;
        }
    } while(1);
}