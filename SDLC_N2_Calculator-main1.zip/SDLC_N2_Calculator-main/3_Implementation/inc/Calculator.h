# ifndef __CALCULATOR_H
# define __CALCULATOR_H

# include"Combinatorics.h"
# include"Arithmetic.h"
# include"Matrix.h"
#include"profitloss.h"
#include"physics.h"

void calculator();

# endif
