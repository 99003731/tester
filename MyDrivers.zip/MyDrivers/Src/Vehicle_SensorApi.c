#include"Vehicle_SensorApi.h"
#include "stm32f4xx_hal.h"

void DoorLatchDetector(void)
{
		 GPIO_PinState LDR_input = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7);
	  	  if(LDR_input == GPIO_PIN_RESET)
	  	  {
	  		  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
	  		  HAL_Delay(2000);
	  	  }
	  	  else
	  	  {
	  		  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
	  		  HAL_Delay(2000);
	  	  }
}

GPIO_PinState PIRState=GPIO_PIN_RESET;
void ParkingAssist(void)
{
	     GPIO_PinState PIR_input = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
		  if(PIR_input == GPIO_PIN_SET)
		   {
		     HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, GPIO_PIN_SET);
		      if(PIRState==GPIO_PIN_RESET)
		      {
		    	  PIRState==GPIO_PIN_SET;
		      }
		    }
		  else
		  {
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_15, GPIO_PIN_RESET);
			  if(PIRState==GPIO_PIN_SET)
			  {
				  PIRState==GPIO_PIN_RESET;
			   }
		  }
}


void wipersystem(void)
{
	GPIO_PinState Rain_input = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_3);
    if(Rain_input == GPIO_PIN_SET)
	 {
	    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
	  }
	 else
	 {
			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
	 }
}


void nightmodelight(void)
{

	  //DOOR LIGHT ON/OFF USING LDR SENSOR
	    read_pin= HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6);



	    	     if(read_pin==1)
	    	     {
	    	         HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);



	    	         HAL_Delay(500);



	    	         HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
	    	         //HAL_Delay(500);
	    	     }
	    	     else
	    	     {
	    	         HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
	    	         HAL_Delay(500);



	    	         HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
	    	    //     HAL_Delay(500);



	    	     }
}

void carstartoff(void)
{
	//Car ON And OFF
		  if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_0) == GPIO_PIN_SET)
		  	  {
			      HAL_Delay(500);
		  		  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_SET);
		  		  if(HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_12) == GPIO_PIN_SET)
		  		  {
		  			  HAL_Delay(500);
		  			  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
		  			  HAL_Delay(200);
		  		  }
		  	  }
		  	  else
		  	 {
		  		 HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
		  	 }
}
