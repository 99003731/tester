# ifndef __math_Functions_H
# define __math_Functions_H
#include<stdio.h>

void math_Functions();
double logarithm(double); //function for logarithm
double exponent(float); //function for exponent
double squareroot(double); //function for exponent
double trigonometry(double); //function for exponent

#endif
