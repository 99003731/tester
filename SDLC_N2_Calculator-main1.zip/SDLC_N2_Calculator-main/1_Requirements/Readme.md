# Requirements
## Introduction
This is a multi-purpose low cost scientific calculator which has near about 4-5 new modes compare to the scientific calculator which already in the market.

## Research
**Cost Vs Feature Curve**

![image](https://user-images.githubusercontent.com/78870813/107804018-68bb8900-6d89-11eb-830a-bfa493787eb4.png)

## Cost and Features(Our system)
**1.Cost is near about 1000-1500 Rs**

***2.Features included***

1. Basic arithmetic operation

2. Physics operation

3. Matrix operations

4. Combinatorics operations

5. Mensuration 

6. Profit and Loss operation

7. Combinatorics (permutation and combination)

8. Finance’s operation

9. Special Math Functions (Exponential, Trigonometric, logarithmic)

## SWOT ANALYSIS
![image](https://user-images.githubusercontent.com/78870813/107805100-dfa55180-6d8a-11eb-9979-993496097486.png)

# 4W&#39;s and 1&#39;H

## Who:

**Generally businessman, engineers ,students and scientist uses calculator but they use different calculator for each purpose.**

## What:

**There are already so many types of calculator that exist in the market already for making our life easier. Few of the calculators we have researched are basic calculator, scientific calculator, financial, graphing ,printing calculator etc.**

## When:

**This requirement of this type of calculator started because firstly manual calculations are difficult.**

## Where:

**It can be used for design analysis of various mechanical equipment’s such as spaceships, vehicle’s speed and diagnostic analysis etc.**

## How:

**We are going to make functions the necessary physics phenomena’s which are difficult to calculate manually.**
