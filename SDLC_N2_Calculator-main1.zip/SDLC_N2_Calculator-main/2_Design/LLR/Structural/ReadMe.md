# Design
## Low Level Design 
![image](https://user-images.githubusercontent.com/78870813/107810914-69f1b380-6d93-11eb-9e1e-362f66d2c778.png)
<br>
**Physics calculation Class Diagram**
<br>
![class](https://user-images.githubusercontent.com/78867415/107842767-b5d04700-6deb-11eb-89ab-2d0b7d4aa8e6.PNG)















![Class diagram](https://user-images.githubusercontent.com/78858575/107872104-b50fe180-6ecd-11eb-91e9-9d4595b6cd9b.jpg)

