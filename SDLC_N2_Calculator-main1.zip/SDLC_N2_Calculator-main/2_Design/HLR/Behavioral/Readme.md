![seqential](https://user-images.githubusercontent.com/78857812/107847099-b3cbaf80-6e0e-11eb-97ad-6c67b8a698a9.png)








![HLR using USE CASE diagram](https://user-images.githubusercontent.com/78858575/107872490-a971ea00-6ed0-11eb-9640-18739766d8f3.jpg)

