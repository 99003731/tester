# include<stdio.h>
# include"mystring.h"

int mystrlen(char *mystring)
{
    int l;
    for(l=0;mystring[l]!='\0';l++);
    return l;
}

char* mystrcpy(char *dest_string,const char *src_string)
{
    int i;
    for(i=0;src_string[i]!='\0';i++)
    {
        dest_string[i]=src_string[i];
    }
    dest_string[i]='\0';
    return dest_string;
}

char* mystrcat(const char *mystring1,const char *mystring2)
{
    int i,j,k=0;
    char *concat_string;
    for(i=0;mystring1[i]!='\0';i++)
    {
        concat_string[k]=mystring1[i];
        k++;
    }
    for(j=0;mystring2[j]!='\0';j++)
    {
        concat_string[k]=mystring1[j];
        k++;
    }
    concat_string[k]='\0';
    return concat_string;
}

int mystrcmp(const char *mystring1,const char *mystring2)
{
    int l1=mystrlen(mystring1);
    int l2=mystrlen(mystring2);
    if(l1<l2)
    {
        return -1;
    }
    else
    if(l1>l2)
    {
        return 1;
    }
    else
    {
        int i,j,flag=0;
        for(i=0,j=0;i<l1;i++,j++)
        {
            if(mystring1[i]!=mystring2[j])
            {
                flag=1;
                break;
            }
        }
        if(flag==0)
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
}