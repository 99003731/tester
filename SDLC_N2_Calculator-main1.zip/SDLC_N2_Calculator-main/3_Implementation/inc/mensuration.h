# ifndef __mensuration_H
# define __mensuration_H

#include<stdio.h> 

void mensuration();
double area_of_square(double);
double area_of_circle(double);
double area_of_sphere(double);
double volume_of_sphere(double);



# endif 

