# ifndef __COMBINATORICS_H
# define __COMBINATORICS_H
#include<stdio.h>

void combinatorics();
double factorial(int);
double permutations(int,int);
double combinations(int,int);

#endif