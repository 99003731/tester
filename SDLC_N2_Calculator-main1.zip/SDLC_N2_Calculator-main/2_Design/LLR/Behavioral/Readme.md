# Design
## Low Level Requirement
![image](https://user-images.githubusercontent.com/78870813/107811162-c359e280-6d93-11eb-989f-4f0c05d5913f.png)




![LLR (Sequential)](https://user-images.githubusercontent.com/78857812/107847570-b0d2be00-6e12-11eb-93c8-edec75a9ba7b.png)














![LLR](https://user-images.githubusercontent.com/78858575/107871697-f43c3380-6ec9-11eb-909c-057b4a3e423a.jpg)





![use case](https://user-images.githubusercontent.com/78867415/107941740-2c1da680-6fb0-11eb-8374-4d878cebaf77.PNG)
