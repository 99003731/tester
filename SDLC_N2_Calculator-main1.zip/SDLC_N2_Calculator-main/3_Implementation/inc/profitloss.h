#ifndef __PROFITLOSS_H
#define __PROFITLOSS_H

#include <stdio.h>

void profit_loss();
double cal_profit(float, float);
double discount(float, float);

#endif /* #define __CALCULATOR_OPERATIONS_H__ */