# include "mystring.h"
#include "myutils.h"
#include"bitmask.h"

/*Required by the unit Test framework*/
void setUp(){}
/*Required by the unit Test framework*/
void tearDown(){}


int main()
{

   UNITY_BEGIN();

    RUN_TEST(test_factorial_positive_num);
    RUN_TEST(test_factorial_negative_num);
    RUN_TEST(test_zero_factorial);

   return UNITY_END();
}