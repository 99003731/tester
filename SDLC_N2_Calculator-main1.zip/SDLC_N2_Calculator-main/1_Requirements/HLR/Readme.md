
##  High level Requirements:
| ID | Requirements | Description | Status |
| --- | --- | --- | --- |
| HLRAM001 | Physics Calculation | Several Physics functions are implemented | Implementing |
| HLRAM002 | Profit and Loss Calculation | Day to Day use of profit and loss function make it more useful | Implementing |
| HLRSS003 | Basic Arithmetic Calculations | Very basic operations like +,-,/,* | Implementing |
| HLRSS004 | Matrix operation | Several Matrix functions | Future |
| HLRSS005 | Combinatorics Calculation | Permutation and Combination | Implementing |
| HLRSA006 | Addition of Special math functions | Several math operations | Implementing |
| HLRSA007 | Addition of financial calculation | Interest Calculations | Implementing |
| HLRPK008 | Mensuration | Area,Volume| Implementing |
| HLRPK009 | AP,GP,Sum| Mean | Implementing |














