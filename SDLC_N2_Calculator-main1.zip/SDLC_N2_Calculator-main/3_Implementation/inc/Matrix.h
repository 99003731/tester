# ifndef __MATRIX_H
# define __MATRIX_H

# include<stdio.h>

void MatrixOperations();
void Matinput(int**,int,int);
void determinant(int**,int);
void Mat_addition(int**,int**,int,int);
void Mat_Subtraction(int**,int**,int,int);
void Mat_Multiply(int**,int**,int,int,int,int);

# endif
