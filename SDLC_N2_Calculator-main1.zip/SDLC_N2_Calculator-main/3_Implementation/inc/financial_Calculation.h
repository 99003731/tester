# ifndef __FINANCE_CALCULATION_H
# define __FINANCE_CALCULATION_H

# include <stdio.h> 

void financial_Calculation();
double simple_Interest(double,float,float); //simple interest function
double compound_Interest(double,float,float); //compound interest function
double emi_Calculator(double,float,float); // emi calculator function

# endif 
