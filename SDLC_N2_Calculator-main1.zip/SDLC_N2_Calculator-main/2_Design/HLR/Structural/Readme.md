# Design

## High Level Design 

![image](https://user-images.githubusercontent.com/78870813/107810413-a07afe80-6d92-11eb-97e9-55cde87ae45a.png)
<br>
**Component Diagram**![Component class HLR](https://user-images.githubusercontent.com/78867415/107797668-2f7f1b00-6d81-11eb-9e3d-30ddc5f29ae6.png)
