#ifndef _VEHICLE_SENSORAPI_H
#define _VEHICLE_SENSORAPI_H

#include "stm32f4xx_hal.h"

void DoorLatchDetector(void);
void ParkingAssist(void);
void wipersystem(void);
void nightmodelight(void);
void carstartoff(void);



#endif
