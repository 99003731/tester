/**
 * @file stringfunction.h
 * @author Shivanshu Shukla (shivanshu.shukla@ltts.com)
 * @brief Executing various string functions
 * @version 0.1
 * @date 2021-02-23
 * 
 * @copyright Copyright (c) 2021
 * 
 */

# ifndef _MYSTRING_H_
# define _MYSTRING_H_

int mystrlen(const char *mystring);
char* mystrcpy(char *dest_string,const char *src_string);
char* mystrcat(const char *mystring1,const char *mystring2);
int mystrcmp(const char *mystring1,const char *mystring2);

# endif