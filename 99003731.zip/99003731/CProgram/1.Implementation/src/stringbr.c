#include <stringbr.h>
#include  <stdio.h>
#include  <string.h>

char* stringbreak(char *s)
{
  const char c='$';
  char *str1;
  char *str2;
  char *token;
  str1=strrchr(s,c);
  token=strtok(str1,";");
  str2=strcat(token,";");
  
  return str2;
}